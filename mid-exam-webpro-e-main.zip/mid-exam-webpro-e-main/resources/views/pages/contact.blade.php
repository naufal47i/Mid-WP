@extends('layouts.app')

@section('content')
    <h1>ini contact SISCO</h1>
@endsection
